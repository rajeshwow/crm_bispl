<?php

// Connecting with database
$connection = mysqli_connect("localhost", "root", "", "my_db");

// Getting current date
$date_time = date("Y-m-d");

// Inserting in database
mysqli_query($connection, "INSERT INTO my_table(current_date) VALUES('$date_time')");
