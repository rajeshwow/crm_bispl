Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/autocomplete-data-on-multiple-fields-with-jquery-and-ajax/


Instructions -

1. Import attached users.sql file in your database.
2. Update config.php file.